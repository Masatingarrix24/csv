public class DemoApplication {

    public static void main(String[] args) throws IOException {

        CsvMapper mapper = new CsvMapper();
        // ヘッダなし
        CsvSchema schema = mapper.schemaFor(User.class);

        Path path = Paths.get("/Users/sakabatomokana/Documents/iGrus/test_csv.csv");
        try (BufferedReader br = Files.newBufferedReader(path)) {

            MappingIterator<User> it = mapper.readerFor(User.class).with(schema).readValues(br);

            // CSVファイルを1行ずつ読み込む場合
            while (it.hasNextValue()) {
                
                User user = it.nextValue();

                // User(id=001, name=Alice, age=18)
                // User(id=002, name=Bob, age=25)
                // User(id=003, name=Carol, age=23)
                System.out.println(user.toString());
            }

            // CSVファイルを全行まとめて読み込む場合
            List<User> userList = it.readAll();
            for (User user : userList) {

                // User(id=001, name=Alice, age=18)
                // User(id=002, name=Bob, age=25)
                // User(id=003, name=Carol, age=23)
                System.out.println(user.toString());
            }
        }
    }
}