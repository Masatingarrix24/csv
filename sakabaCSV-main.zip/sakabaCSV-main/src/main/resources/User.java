// CSVの各項目を読み込む順序を設定する
@JsonPropertyOrder({"id", "name", "age"})
public class User {

    private String id;
    private String name;
    private int age;

    public User(String id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    // デフォルトコンストラクタを定義する必要がある
    public User() {
    }

    // getter, setter, toStringは省略
}